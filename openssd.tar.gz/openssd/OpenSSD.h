#ifndef OPENSSD_H_INCLUDED
#define OPENSSD_H_INCLUDED
#include <stdio.h>
#include <algorithm>
#include <iostream>
#include <vector>

#define SortSize 1000
int partialSort(unsigned char *arr,unsigned char *index);
void binprint(unsigned char *buf, int len, int width);
#endif // OPENSSD_H_INCLUDED
