#include <stdio.h>
#include <algorithm>
#include <iostream>
#include <vector>
#include "OpenSSD.h"
#include "OpenSSD_API.h"
using namespace std;
extern "C"
{
    #include "nvme_low_lib.h"
}

int main(int argc, char *argv[]) {


  char dev[] = "/dev/nvme0n63516160p1";
  //char weight_file[20];
  char image_file[20];
  char weight_file[] = "/home/nvme/input.bin";
  //char image_file[] = "/home/nvme/image_data/07.bin";
  char input;
  int image_flag=0;
  /*printf("\n---input weight file path---\n");

  cin>>weight_file;*/

  printf("\n---input image file path---\n");

  cin>>image_file;
  printf("\n---only run image process? [y][n]---\n");
  cin>>input;
  if(input =='y')
  {
    image_flag=1;
    image_flag = Run_OpenSSD(dev,weight_file,image_file,image_flag);
  }
  else
  {

  printf("\n---now start weight map process---\n");

  image_flag = Run_OpenSSD(dev,weight_file,image_file,image_flag);
  if(image_flag ==1)
  {
    printf("\n---now start image  process?-[y][n]?----\n");
    cin>>input;
    if(input =='y')
    {
        image_flag = Run_OpenSSD(dev,weight_file,image_file,image_flag);
    }
    else
    {
        printf("\n---now stop image  process---\n");
    }
  }

  }


  return 0;
}



